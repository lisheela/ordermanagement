package com.market.ordermanagement.eureka;

public @interface EnableEurekaServer {

}
